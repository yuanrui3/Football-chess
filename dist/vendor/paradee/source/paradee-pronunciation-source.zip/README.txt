Football Chess — pronunciation source package
Prepared 2026-10-16. These files support the unmodified phonemizer 1.2.1
runtime used by the Paradee local commentary voice. They are source and
license material, not loaded or downloaded during speech generation.

Included:
* phonemizer-1.2.1-source.tar.gz: full source tree, including src/phonemizer.js,
  src/espeakng.worker.js (the unminified generated engine), embedded English
  data, package.json, package-lock.json, Rollup build and tests.
  Upstream: https://github.com/xenova/phonemizer.js
  Exact commit: 6835144b7ee9043129222549c1ed2f6a27216278
* phonemizer-1.2.1-npm.tgz: the exact upstream npm distribution.
* espeak-ng-0dfd1d77-source.tar.gz: complete eSpeak NG C/C++ and data sources,
  including emscripten/Makefile, glue C++, IDL and build instructions.
  Upstream: https://github.com/espeak-ng/espeak-ng
  Commit: 0dfd1d77dd7f96ef1ea6856c9fa5cfac01599582
* GPL-3.0.txt: eSpeak NG license; PHONEMIZER-APACHE-2.0.txt: wrapper license.
* verify-embedded-data.py: checks the bundled engine's plain data files
  against this eSpeak source and reports hashes.

Rebuild the phonemizer distribution (Node.js/npm required):
  tar -xzf phonemizer-1.2.1-source.tar.gz
  cd phonemizer-1.2.1
  npm ci
  npm run build
The output is dist/phonemizer.js and dist/phonemizer.cjs. This rebuild uses the
same upstream unminified generated engine. The runtime is not modified.

To rebuild eSpeak's C/C++ engine, extract the eSpeak archive and follow
emscripten/README.md and emscripten/Makefile (also copied as
ESPEAK-BUILD-INSTRUCTIONS.md). The included JavaScript engine identifies
Emscripten 3.1.30 in its embedded compiler strings. The Makefile uses WASM=0,
so this particular pronunciation engine is compiled JavaScript/asm.js; the
separate ONNX inference runtime is WebAssembly.

Provenance verification:
All 328 plain language/voice files embedded in phonemizer 1.2.1 are byte-for-
byte identical to the included eSpeak commit. Five other embedded files
(en_dict, intonations, phondata, phonindex, phontab) are compiled data, for
which the source inputs are in the eSpeak archive. The phonemizer publisher
does not identify the exact C/C++ revision used to build its generated engine.
Therefore this package records the verified data match; it does not claim a
verified bit-for-bit rebuild of the underlying C/C++ engine.

Licensing:
The wrapper is Apache License 2.0; the eSpeak NG engine is GPL version 3 or
later. Original license and copyright notices remain in the complete source.
You may copy, modify and redistribute those components under those licenses.
No eSpeak or phonemizer code was modified for the game. The Paradee model and
Misaki conversion have separate Apache-2.0 notices with the game's voice
assets. ONNX Runtime has separate MIT and third-party notices there.

Source material is made available with the runtime at no additional charge.
