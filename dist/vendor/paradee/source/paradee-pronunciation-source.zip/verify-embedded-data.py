#!/usr/bin/env python3
"""Verify embedded eSpeak plain data against the provided complete source."""
from pathlib import Path
import base64
import gzip
import hashlib
import json
import re
import tarfile

here = Path(__file__).resolve().parent
with tarfile.open(here / "phonemizer-1.2.1-source.tar.gz") as wrapper:
    script = wrapper.extractfile("phonemizer-1.2.1/src/espeakng.worker.js").read().decode()
embedded = gzip.decompress(base64.b64decode(
    re.search(r'const WORKER_DATA\s*=\s*"([^"]+)"', script).group(1)
))
matches, differences, compiled = [], [], []
with tarfile.open(here / "espeak-ng-0dfd1d77-source.tar.gz") as source:
    root = source.getnames()[0]
    for expr, start, end in re.findall(
        r"filename: (.*?),\s+start: (\d+),\s+end: (\d+)", script
    ):
        prefix, filename = re.match(r'(\w+) \+ "(.*)"', expr).groups()
        filename = {"base": "", "lang_dir": "/lang", "voices_dir": "/voices"}[prefix] + filename
        data = embedded[int(start):int(end)]
        try:
            original = source.extractfile(root + "/espeak-ng-data" + filename).read()
        except (KeyError, AttributeError):
            compiled.append(filename)
            continue
        (matches if data == original else differences).append(filename)
report = {
    "plain_data_files_matched": len(matches),
    "plain_data_files_different": differences,
    "compiled_data_files": compiled,
    "archives": {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(here.glob("*.tar.gz"))
    },
}
print(json.dumps(report, indent=2))
raise SystemExit(0 if len(matches) == 328 and not differences else 1)
