import fs from 'node:fs';
import * as acorn from 'acorn';
const s=fs.readFileSync('examples/html/assets/kittentts-web.js','utf8');
const a=acorn.parse(s,{ecmaVersion:'latest',sourceType:'script'});
let node;
function walk(n){if(!n||typeof n!=='object')return;if(n.type==='FunctionDeclaration'&&n.id?.name==='_L'){node=n;return;}for(const v of Object.values(n))if(Array.isArray(v))v.forEach(walk);else if(v&&typeof v==='object')walk(v)}
walk(a);
if(!node)throw Error('Factory not found');
const helper=s.slice(s.indexOf('var qL='),s.indexOf('var XR='));
fs.writeFileSync('cephonemizer-runtime.js',helper+'\nconst $L={};\n'+s.slice(node.start,node.end)+'\nexport default _L;\n');
