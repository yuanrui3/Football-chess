# KittenTTS English pronunciation frontend source

Upstream: https://github.com/KittenML/KittenTTS-web
Exact commit: c846fe92858f3447f4912226471f5a63983b3f94
Apache-2.0 engine and TypeScript frontend source included.

The generated CE phonemizer factory was extracted unchanged from the checked-in examples/html/assets/kittentts-web.js IIFE bundle, together with the bundle helper definitions used by that factory. A new ES module default export was added. No synthesis SDK, analytics, ONNX Runtime, or MP3 encoder code from that larger bundle is executed or shipped in the extracted frontend.

The generated TextCleaner.js and TextPreprocessor.js are transpiled from the included exact TypeScript source with TypeScript5.8.3 targeting ES2022; comments preserved.

The en_rules and en_list are unmodified plain-text pronunciation files from espeak-ng commit59eb19938f12e30881c81d86ce4a7de25414c9f4 under GPLv3. Their source form and COPYING are included directly. The CE engine authors state their parser is an original Apache2 implementation, not derived from GPL reference engine code.

The upstream build script is supplied; extraction is recorded below and can be reproduced without Emscripten from the supplied checked-in bundle.
